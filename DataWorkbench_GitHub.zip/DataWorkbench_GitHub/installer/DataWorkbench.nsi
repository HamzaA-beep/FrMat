Unicode true
!include "MUI2.nsh"

!define APP_NAME "Data Workbench"
!define APP_EXE "DataWorkbench.exe"
Name "${APP_NAME}"
OutFile "dist\DataWorkbenchSetup.exe"
InstallDir "$LOCALAPPDATA\Programs\DataWorkbench"
RequestExecutionLevel user
SetCompressor /SOLID lzma
ShowInstDetails show
ShowUninstDetails show

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Section "Install" SecInstall
  SetOutPath "$INSTDIR"
  File /r "dist\DataWorkbench\*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateDirectory "$SMPROGRAMS\Data Workbench"
  CreateShortcut "$SMPROGRAMS\Data Workbench\Data Workbench.lnk" "$INSTDIR\${APP_EXE}"
  CreateShortcut "$SMPROGRAMS\Data Workbench\Uninstall Data Workbench.lnk" "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DataWorkbench" "DisplayName" "${APP_NAME}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DataWorkbench" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DataWorkbench" "InstallLocation" "$INSTDIR"
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DataWorkbench" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DataWorkbench" "NoRepair" 1
SectionEnd

Section "Uninstall"
  Delete "$SMPROGRAMS\Data Workbench\Data Workbench.lnk"
  Delete "$SMPROGRAMS\Data Workbench\Uninstall Data Workbench.lnk"
  RMDir "$SMPROGRAMS\Data Workbench"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\DataWorkbench"
  RMDir /r "$INSTDIR"
  ; The workspace in $LOCALAPPDATA\DataWorkbench is intentionally retained.
SectionEnd
