$ErrorActionPreference = 'Stop'
$project = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$destination = Join-Path $env:LOCALAPPDATA 'Programs\DataWorkbench-Source'
if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw 'Install Python 3.12 (64-bit) with the Python launcher first.'
}
New-Item -ItemType Directory -Force -Path $destination | Out-Null
Copy-Item (Join-Path $project 'data_workbench.py') $destination -Force
Copy-Item (Join-Path $project 'requirements.txt') $destination -Force
& py -3.12 -m venv (Join-Path $destination '.venv')
if ($LASTEXITCODE -ne 0) { throw 'Python 3.12 is required.' }
$python = Join-Path $destination '.venv\Scripts\python.exe'
& $python -m pip install -r (Join-Path $destination 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed; check your internet connection.' }
$shortcutPath = Join-Path ([Environment]::GetFolderPath('Programs')) 'Data Workbench (Source).lnk'
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut($shortcutPath)
$link.TargetPath = Join-Path $destination '.venv\Scripts\pythonw.exe'
$link.Arguments = '"' + (Join-Path $destination 'data_workbench.py') + '"'
$link.WorkingDirectory = $destination
$link.Save()
Write-Host "Installed to $destination"
Write-Host "Start Menu shortcut: $shortcutPath"
