$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '..'))
$python = (Get-Command py -ErrorAction SilentlyContinue)
if (-not $python) { throw 'Install Python 3.12 (64-bit) and the Python launcher first.' }
& py -3.12 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Could not create Python 3.12 virtual environment.' }
$pip = Join-Path $PWD '.venv\Scripts\python.exe'
& $pip -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }
& $pip -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
& $pip -m PyInstaller --noconfirm --clean --onedir --windowed --name DataWorkbench `
    --collect-all matplotlib --collect-all pandas --collect-all pdfplumber `
    --collect-all docx --collect-all openpyxl --collect-all xlrd `
    --collect-all defusedxml --collect-all reportlab --collect-all lxml `
    data_workbench.py
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller build failed.' }

$nsis = Get-Command makensis.exe -ErrorAction SilentlyContinue
if ($nsis) {
    $makensis = $nsis.Source
} elseif (Test-Path "${env:ProgramFiles(x86)}\NSIS\makensis.exe") {
    $makensis = "${env:ProgramFiles(x86)}\NSIS\makensis.exe"
} elseif (Test-Path "$env:ProgramFiles\NSIS\makensis.exe") {
    $makensis = "$env:ProgramFiles\NSIS\makensis.exe"
} else {
    throw 'Install NSIS (Nullsoft Scriptable Install System), then run this script again.'
}
& $makensis 'installer\DataWorkbench.nsi'
if ($LASTEXITCODE -ne 0) { throw 'NSIS installer build failed.' }
Write-Host 'Installer created: dist\DataWorkbenchSetup.exe'
